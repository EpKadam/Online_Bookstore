<div class="gallery-main" style="margin-left:25%;padding:1px 16px;height:1000px;">
                <div class="Adventure" id="Adventure">
                    <h2>Adventure</h2>

                    <div class="gallery">
                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse4.mm.bing.net/th?id=OIP.wxSklXRuxRUgtUguejI6oQHaLG&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 200
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>
               
                        <div class="gallery-main" style="margin-left:25%;padding:1px 16px;height:1000px;">
    <div class="Adventure" id="Adventure">
        <h2>Adventure</h2>

        <div class="gallery">
            <div class="image-holder">
                <a href="#">
                    <img src="https://tse4.mm.bing.net/th?id=OIP.wxSklXRuxRUgtUguejI6oQHaLG&pid=Api&P=0&h=180" alt="img-1">
                </a>
                <div class="desc">
                    Price: 200
                    <br>
                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                    <form method="POST" action="buyproduct.php">
                        <input type="hidden" name="product_id" value="1"> <!-- Product ID -->
                        <input type="hidden" name="price" value="200">    <!-- Product Price -->
                        <button type="submit">Buy</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse1.mm.bing.net/th?id=OIP.ilwkGHuv48R2LV70hNh1QQHaKO&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 250
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>

                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse2.mm.bing.net/th?id=OIP.I6wNsM2--7jpEhQboa7SNgHaLX&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 180
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>

                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse2.mm.bing.net/th?id=OIP.sXaMcl9-iABCeuu23OEw2AAAAA&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 460
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>

                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse3.mm.bing.net/th?id=OIP.ROT2bAw9JS5AAMZMdit2UAHaMS&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 390
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>

                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse4.mm.bing.net/th?id=OIP.JrFeh1SONFxn7Xc5CFPZZAHaLE&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 100
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>

                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse3.mm.bing.net/th?id=OIP.VD7T76PC-1I2tLpt2xjfYgAAAA&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 304
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>

                        <div class="image-holder">
                            <a href="#">
                                <img src="https://tse2.mm.bing.net/th?id=OIP.IIIPIPZYMBOJgxFfWGRtBAHaHa&pid=Api&P=0&h=180" alt="img-1">
                            </a>
                            <div class="desc">
                                Price : 340
                                <br>
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                <button>Buy</button>
                            </div>
                        </div>

                    </div>

                    <!-- Thriller -->

                    <div class="Thriller" id="Thriller">
                        <h2>Thriller</h2>
    
                        <div class="gallery">
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://raw.githubusercontent.com/himanshi-15/Book-Store/refs/heads/main/BookStore/images/th1.jfif" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 120
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://tse2.mm.bing.net/th?id=OIP.F23lLhPdFgj0FgSkL2zLagHaLG&pid=Api&P=0&h=180" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 402
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://raw.githubusercontent.com/himanshi-15/Book-Store/refs/heads/main/BookStore/images/th3.jfif" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 299
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://tse1.mm.bing.net/th?id=OIP.P9bW-BW9o-wpsFow4hEL3gAAAA&pid=Api&P=0&h=180" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 150
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://raw.githubusercontent.com/himanshi-15/Book-Store/refs/heads/main/BookStore/images/th6.jfif" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 300
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://tse4.mm.bing.net/th?id=OIP.AnjHEC7tpVrwpp9j4X8QAAHaLM&pid=Api&P=0&h=180" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 389
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://raw.githubusercontent.com/himanshi-15/Book-Store/refs/heads/main/BookStore/images/th7.jfif" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 269
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
                            <div class="image-holder">
                                <a href="#">
                                    <img src="https://tse3.mm.bing.net/th?id=OIP.tMHicPVU6wVP7rEhVzb-JgHaLH&pid=Api&P=0&h=180" alt="img-1">
                                </a>
                                <div class="desc">
                                    Price : 451
                                    <br>
                                    <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                    <button>Buy</button>
                                </div>
                            </div>
    
    
                        </div>

                        <!-- Engineering books -->
                        <div class="Engineering" id="Romantic">
                            <h2>Engineering</h2>
        
                            <div class="gallery">
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse4.mm.bing.net/th?id=OIP.UROw4BE_OcL_4LMnHgl1iQHaLY&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 250
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse3.mm.bing.net/th?id=OIP.kfcMfSTBH11QxEd5X5I9kQHaLG&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 300
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse2.mm.bing.net/th?id=OIP.5amc_1Ho7hfP87tUfbkv6AHaJP&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 450
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse2.mm.bing.net/th?id=OIP.915C1odTlPWFhZT-Qcz3ewHaL5&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 299
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse4.mm.bing.net/th?id=OIP.5t6Q6iZxfGJ_q_rk5E0OkQAAAA&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 105
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse2.mm.bing.net/th?id=OIP.TXa2I8ECNW6HxFggphRVkgAAAA&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 199
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse2.mm.bing.net/th?id=OIP.TDhqosVGNKANOq76ssRGkAHaLH&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 299
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
                                <div class="image-holder">
                                    <a href="#">
                                        <img src="https://tse4.mm.bing.net/th?id=OIP.8JYLqTJ6BlAcTTuLdOlqiAHaJo&pid=Api&P=0&h=180" alt="img-1">
                                    </a>
                                    <div class="desc">
                                        Price : 349
                                        <br>
                                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                        <button>Buy</button>
                                    </div>
                                </div>
        
        
                            </div>

                            <!-- Comedy -->
                            <div class="Comedy" id="Comedy">
                                <h2>Comedy</h2>
            
                                <div class="gallery">
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://tse3.mm.bing.net/th?id=OIP.cJxhqrZ2xjnkG2vmcEascwHaLH&pid=Api&P=0&h=180" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 400
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://tse4.mm.bing.net/th?id=OIP.sDZ216OrQFgmRe__LwocewHaLX&pid=Api&P=0&h=180" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 299
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://tse3.mm.bing.net/th?id=OIP.74EIznZlMX0rtIrY1sYUdgHaLH&pid=Api&P=0&h=180" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 349
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://tse4.mm.bing.net/th?id=OIP.qAK_YPy9vvCvofQkLFSHhQAAAA&pid=Api&P=0&h=180" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 299
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://tse1.mm.bing.net/th?id=OIP.ubf-n_NiByPOF4MyTP-47wHaLH&pid=Api&P=0&h=180" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 199
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://tse4.mm.bing.net/th?id=OIP.iZStTKrEyKpT_w8Ef6p2qgHaJ3&pid=Api&P=0&h=180" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 149
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/jokes-comedy-book-cover-design-template-e33d03d82f1b2aaee1950a10890af620_screen.jpg?ts=1666207865" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 349
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
                                    <div class="image-holder">
                                        <a href="#">
                                            <img src="https://tse2.mm.bing.net/th?id=OIP.QtII7E0YaRZT9mBL7ZF_KgAAAA&pid=Api&P=0&h=180" alt="img-1">
                                        </a>
                                        <div class="desc">
                                            Price : 250
                                            <br>
                                            <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                                            <button>Buy</button>
                                        </div>
                                    </div>
            
            
                                </div>
        
                                
                            
                </div>
            </div>

            <br>

            <right> <a href="/index.html" class="btn">Back <i class="fa fa-arrow-right" aria-hidden="true"></i> </a></right>
              

        </div>